import json
import re
import time
import os
from datetime import datetime

class ImpatienceDetectionAgent:
    """
    ImpatienceDetectionAgent: Detects impatience, frustration, and emotional stress in the user.
    Flags emotional burnout risks and provides interventions to help regulate emotions.
    """

    def __init__(self, hub=None):
        self.hub = hub
        self.swear_words = {"fuck", "shit", "damn", "bollocks", "hell"}
        self.short_command_threshold = 3
        self.reward_system = {"impatience_reduction": 10, "calm_feedback": 5}
        self.rl_feedback_threshold = 5

        self.impatience_data_file = "data/impatience_data.json"
        self.reward_log_file = "data/rewards/impatience_rewards.json"
        self.recent_inputs = []
        self.time_window = 5 * 60
        self.impatience_score = 0
        self.impatience_decay_rate = 0.5
        self.emotional_state_data = []

        self.load_impatience_data()

    def load_impatience_data(self):
        try:
            with open(self.impatience_data_file, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, dict):
                    self.emotional_state_data = data.get("data", [])
                else:
                    self.emotional_state_data = []
        except FileNotFoundError:
            self.emotional_state_data = []

    def analyze(self, input_text: str) -> int:
        input_text = input_text.strip()
        word_count = len(input_text.split())
        swears = sum(1 for word in re.findall(r'\b\w+\b', input_text.lower()) if word in self.swear_words)

        score = 0
        if swears > 0:
            score += swears
        if word_count <= self.short_command_threshold:
            score += 1
        if input_text.endswith("!"):
            score += 1

        return score

    def update_impatience(self, input_text: str):
        current_time = time.time()
        instant_score = self.analyze(input_text)

        self.recent_inputs.append((current_time, instant_score))
        self.recent_inputs = [
            (ts, score) for ts, score in self.recent_inputs
            if current_time - ts <= self.time_window
        ]

        decayed_scores = []
        for ts, score in self.recent_inputs:
            age = current_time - ts
            decay_factor = max(0.5, 1 - (age / self.time_window) * self.impatience_decay_rate)
            decayed_scores.append(score * decay_factor)

        self.impatience_score = sum(decayed_scores)

        if self.impatience_score <= 5:
            impatience_meter = "low"
        elif self.impatience_score <= 10:
            impatience_meter = "medium"
        elif self.impatience_score <= 15:
            impatience_meter = "high"
        else:
            impatience_meter = "extreme"

        self.save_impatience_data(impatience_meter)
        print(f"Instant score: {instant_score} | Rolling score: {self.impatience_score:.2f} | Impatience level: {impatience_meter}")

    def get_impatience_level(self):
        if self.impatience_score <= 5:
            return "low"
        elif self.impatience_score <= 10:
            return "medium"
        else:
            return "high"

    def get_normalized_score(self):
        return min(1.0, self.impatience_score / 20.0)

    def detect_impatience(self, user_input, emotional_state, source="unspecified"):
        self.update_impatience(user_input)
        impatience_level = self.get_impatience_level()
        suggestion = self._generate_intervention(impatience_level, emotional_state)

        result = {
            "impatience_level": impatience_level,
            "normalized_score": self.get_normalized_score(),
            "suggestion": suggestion,
            "source": source,
            "timestamp": time.time()
        }

        self.emotional_state_data.append({
            "timestamp": result["timestamp"],
            "user_input": user_input,
            "emotional_state": emotional_state,
            "impatience_score": self.impatience_score,
            "normalized_score": result["normalized_score"],
            "impatience_level": impatience_level,
            "suggestion": suggestion,
            "source": source,
            "time_of_day": datetime.now().strftime("%H:%M"),
            "weekday": datetime.now().strftime("%A")
        })

        self.save_impatience_data(impatience_level)

        if impatience_level == "high":
            if self.hub:
                self.hub.update_shadow({"impatience": result})
            else:
                print(f"[ImpatienceDetectionAgent] No hub assigned — shadow update skipped.")

            if emotional_state == "calm":
                self.reward_user("impatience_reduction")

        return result

    def save_impatience_data(self, impatience_meter):
        data_entry = {
            "impatience_score": self.impatience_score,
            "impatience_meter": impatience_meter,
            "normalized_score": self.get_normalized_score(),
            "timestamp": time.time()
        }

        try:
            with open(self.impatience_data_file, "r", encoding="utf-8") as f:
                existing = json.load(f)
                if not isinstance(existing, dict):
                    existing = {"compiled_summary": [], "data": []}
        except FileNotFoundError:
            existing = {"compiled_summary": [], "data": []}

        compiled_summary_entry = {
            "compiled_score_5min": self.impatience_score,
            "compiled_meter_5min": self.get_impatience_level(),
            "normalized_score": self.get_normalized_score(),
            "timestamp": datetime.now().isoformat()
        }

        existing["compiled_summary"].append(compiled_summary_entry)
        existing["data"].append(data_entry)

        with open(self.impatience_data_file, "w", encoding="utf-8") as f:
            json.dump(existing, f, indent=4, default=str)

        print(f"[ImpatienceDetectionAgent] Impatience data saved. Compiled summary and score added.")

    def _generate_intervention(self, impatience_level, emotional_state):
        if impatience_level == "high":
            return "You might be feeling overwhelmed. Take a short break, breathe deeply, or consider reflecting on your goals."
        elif impatience_level == "medium":
            return "You're showing signs of impatience. Maybe try slowing down or taking a moment to refocus."
        elif impatience_level == "low":
            return "You're doing well. Keep it up, but stay mindful of your emotional state."
        return "You're calm, but let's maintain this pace and avoid stress."

    def reward_user(self, reward_type):
        if reward_type == "impatience_reduction":
            reward_points = self.reward_system["impatience_reduction"]
        elif reward_type == "calm_feedback":
            reward_points = self.reward_system["calm_feedback"]
        else:
            reward_points = 0

        reward_entry = {
            "timestamp": time.time(),
            "reward_type": reward_type,
            "reward_points": reward_points
        }

        os.makedirs(os.path.dirname(self.reward_log_file), exist_ok=True)
        if os.path.exists(self.reward_log_file):
            with open(self.reward_log_file, "r", encoding="utf-8") as f:
                rewards = json.load(f)
        else:
            rewards = []

        rewards.append(reward_entry)

        with open(self.reward_log_file, "w", encoding="utf-8") as f:
            json.dump(rewards, f, indent=4)

        if self.hub:
            self.hub.update_shadow({"reward_points": reward_points})
        else:
            print(f"[ImpatienceDetectionAgent] No hub assigned — reward update skipped.")

        print(f"[ImpatienceDetectionAgent] User rewarded with {reward_points} points for {reward_type}.")

    def get_summary_snapshot(self):
        return {
            "impatience_score": self.impatience_score,
            "normalized_score": self.get_normalized_score(),
            "level": self.get_impatience_level(),
            "last_inputs": self.recent_inputs[-3:],
            "emotion_summary": self.emotional_state_data[-3:]
        }

    def predict_next_state(self, user_input):
        """
        Placeholder for future ML model to predict impatience delta or burnout probability.
        """
        return {"predicted_score_change": 0.0}
