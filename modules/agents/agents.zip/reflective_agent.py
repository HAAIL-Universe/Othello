import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional

class ReflectiveAgent:
    """
    ReflectiveAgent: Analyzes recent actions, mood trends, goal progress, and behavioral anomalies.
    Flags changes, tracks momentum, and provides structured summaries.
    Includes RL reward hooks and contradiction checks between shadow and persona.
    """

    def __init__(self, hub=None):
        self.hub = hub
        self.snapshots_file = "data/reflection_snapshots.json"
        self.log_file = "data/reflective_log.json"
        self.last_report = {}
        self.reward_system = {
            "goal_completed": 10,
            "goal_affirmed": 2,
            "goal_progressed": 1,
            "insightful_reflection": 3,
            "anomaly_flagged": 1
        }
        self.rl_feedback_threshold = 5
        self.goals = []
        self.mood_history = []

        if self.hub and hasattr(self.hub, "handle_conversation"):
            self.conversation_insights = self.hub.handle_conversation("Initial reflection setup")
        else:
            self.conversation_insights = {}

    def _load_snapshots(self):
        try:
            with open(self.snapshots_file, "r") as f:
                return json.load(f)
        except Exception:
            return []

    def _save_snapshot(self, snapshot):
        data = self._load_snapshots()
        data.append(snapshot)
        with open(self.snapshots_file, "w") as f:
            json.dump(data, f, indent=2)

    def _get_recent(self, snapshots, days):
        cutoff = datetime.now() - timedelta(days=days)
        return [s for s in snapshots if datetime.fromisoformat(s["timestamp"]) >= cutoff]

    def _detect_shadow_persona_conflict(self, shadow_data):
        persona_traits = shadow_data.get("persona_traits", {})
        shadow_traits = shadow_data.get("traits", {})
        contradictions = []
        for trait, val in persona_traits.items():
            if trait in shadow_traits:
                delta = abs(val - shadow_traits[trait])
                if delta >= 2.0:
                    contradictions.append(trait)
        return contradictions

    def _calculate_mood_momentum(self, mood_history):
        if len(mood_history) < 2:
            return "insufficient data"
        last = mood_history[-1]
        prev = mood_history[-2]
        if last == prev:
            return "stable"
        return "improving" if last > prev else "declining"

    def run_full_reflection(self, shadow_data, user_data=None):
        user_data = user_data or {"text": "", "mood": "", "context": ""}

        snapshots = self._load_snapshots()
        today = {
            "timestamp": datetime.now().isoformat(),
            "mood": shadow_data.get("mood", "neutral"),
            "goal_streak": shadow_data.get("goal_streak", 0),
            "traits": shadow_data.get("traits", {}),
            "reward_points": 0
        }

        recent_1 = self._get_recent(snapshots, 1)
        mood_trend = "stable"
        if recent_1 and recent_1[-1]["mood"] != today["mood"]:
            mood_trend = "changed"

        self.mood_history.append(today["mood"])
        momentum = self._calculate_mood_momentum(self.mood_history)

        goal_streak_change = today["goal_streak"] - (recent_1[-1]["goal_streak"] if recent_1 else 0)
        delta = {
            "mood_trend": mood_trend,
            "mood_momentum": momentum,
            "goal_streak_change": goal_streak_change,
            "traits_delta": today["traits"]
        }

        contradictions = self._detect_shadow_persona_conflict(shadow_data)
        anomalies = []
        if today["goal_streak"] == 0 and today["mood"] == "positive":
            anomalies.append("Positive mood but no goal progress.")

        if contradictions:
            anomalies.extend([f"Trait contradiction: {trait}" for trait in contradictions])

        if today["goal_streak"] > self.rl_feedback_threshold:
            today["reward_points"] += self.reward_system["goal_progressed"]

        if anomalies:
            today["reward_points"] += len(anomalies) * self.reward_system["anomaly_flagged"]

        if mood_trend != "stable" or momentum != "stable":
            today["reward_points"] += self.reward_system["insightful_reflection"]

        summary_text = (
            f"Today's mood: {today['mood']}. "
            f"Mood trend: {mood_trend}. Momentum: {momentum}. "
            f"Goal streak: {today['goal_streak']} (Δ{goal_streak_change})."
        )

        result = {
            "summary_text": summary_text,
            "delta": delta,
            "anomalies": anomalies,
            "reward_points": today["reward_points"]
        }

        self.last_report = result
        snapshot_entry = {**today, **result}
        self._save_snapshot(snapshot_entry)

        with open(self.log_file, "a") as f:
            json.dump(snapshot_entry, f)
            f.write("\n")

        if self.hub:
            self.hub.update_shadow({
                "reward_points": today["reward_points"],
                "anomalies": anomalies,
                "reflection_summary": summary_text
            })
        else:
            print("[ReflectiveAgent] No hub assigned — update skipped.")

        return result

    def apply_rl_for_goal(self):
        if not self.goals:
            print("[ReflectiveAgent] No goals available for RL prioritization.")
            return []

        prioritized_goals = sorted(self.goals, key=lambda g: g.get("reward_points", 0), reverse=True)
        print("[ReflectiveAgent] Goals after RL prioritization:")
        for goal in prioritized_goals:
            print(f"Goal: {goal['description']} | Reward Points: {goal['reward_points']}")
        return prioritized_goals

    def parse_and_update_goals(self, parsed_goals):
        for goal in parsed_goals:
            description = goal.get("description", "")
            status = goal.get("status", "planned")
            tags = goal.get("tags", [])
            self.add_goal(description, status, tags)

    def extract_goals_from_text(self, text: str) -> List[Dict]:
        return [{"description": text, "tags": ["auto"]}]

    def add_goal(self, description: str, status: str = "planned", tags: Optional[List[str]] = None):
        if tags is None:
            tags = []
        new_goal = {
            "description": description,
            "status": status,
            "tags": tags,
            "reward_points": 0
        }
        self.goals.append(new_goal)
        print(f"[ReflectiveAgent] Goal added: {new_goal}")
